function penultimoElemento(lista) {
    return lista[lista.length - 2];
  }
  
  // Exemplo de uso:
  const minhaLista = ["azul", "verde", "preto", "rosa", "cinza", "amarelo"];
  console.log(penultimoElemento(minhaLista)); // Saída: verde
  