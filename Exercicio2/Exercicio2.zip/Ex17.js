function contarOvelhas() {
    for (let i = 1; i <= 5; i++) {
      console.log(`${i} ovelha${i > 1 ? 's' : ''}...`);
    }
  }
  
  contarOvelhas();
  