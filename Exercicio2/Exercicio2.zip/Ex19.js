function listarImparesAte9() {
    for (let i = 1; i < 10; i += 2) {
      console.log(i);
    }
  }
  
  listarImparesAte9();
  