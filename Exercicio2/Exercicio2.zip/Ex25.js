function minhasCoresFavoritas() {
return ["azul", "verde", "preto", "Rosa" ];
  }

  console.log(minhasCoresFavoritas()); 
  